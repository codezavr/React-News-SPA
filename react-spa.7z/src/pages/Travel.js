{/*<Router>*/}
{/*<div>*/}
{/*<ul>*/}
{/*<div className="lol" onClick={this.changeThisState.bind(this)}>CLICKME</div>*/}
{/*<li><Link to="/">Home</Link></li>*/}
{/*<li><Link to="/sport" >Sport</Link></li>*/}
{/*</ul>*/}
{/*<Route exact path="/" component={Layout}/>*/}
{/*<Route exact path="/sport" component={Sport}/>*/}
{/*</div>*/}
{/*</Router>*/}
{/*<div>{this.getNews() + this.props.some}</div>*/}