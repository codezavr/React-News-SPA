{
    "status": "ok",
    "totalResults": 10,
    "articles": [{
        "source": {"id": "bbc-news", "name": "BBC News"},
        "author": "BBC Sport",
        "title": "Roger Federer wins sixth Australian Open and 20th Grand Slam title",
        "description": "Roger Federer wins his sixth Australian Open and 20th Grand Slam title with a five-set victory over Marin Cilic.",
        "url": "http://www.bbc.co.uk/sport/tennis/42851064",
        "urlToImage": "https://ichef.bbci.co.uk/onesport/cps/624/cpsprodpb/13590/production/_97584297_breaking_news.png",
        "publishedAt": "2018-01-28T11:41:34Z"
    }, {
        "source": {"id": "bbc-news", "name": "BBC News"},
        "author": "BBC News",
        "title": "Ikea founder Kamprad dies at 91",
        "description": "Swedish founder of Ikea furniture chain, Ingvar Kamprad, has died at 91, company announces",
        "url": "http://www.bbc.co.uk/news/world-europe-42851668",
        "urlToImage": "https://ichef-1.bbci.co.uk/news/1024/branded_news/7A23/production/_97176213_breaking_news_bigger.png",
        "publishedAt": "2018-01-28T10:40:44Z"
    }, {
        "source": {"id": "bbc-news", "name": "BBC News"},
        "author": "BBC News",
        "title": "'I would have negotiated Brexit differently'",
        "description": "President Trump has told ITV's Piers Morgan that he would have taken a different attitude than Theresa May towards Brexit negotiations.",
        "url": "http://www.bbc.co.uk/news/uk-42850362",
        "urlToImage": "https://ichef-1.bbci.co.uk/news/1024/branded_news/F04E/production/_99781516_p05wbx4t.jpg",
        "publishedAt": "2018-01-28T10:24:36Z"
    }, {
        "source": {"id": "bbc-news", "name": "BBC News"},
        "author": "BBC News",
        "title": "Navalny offices raided on day of protests",
        "description": "Russian police reportedly force their way into the property ahead of nationwide anti-Putin rallies.",
        "url": "http://www.bbc.co.uk/news/world-europe-42850198",
        "urlToImage": "https://ichef-1.bbci.co.uk/news/1024/branded_news/A990/production/_99780434_hi044378489.jpg",
        "publishedAt": "2018-01-28T08:42:38Z"
    }, {
        "source": {"id": "bbc-news", "name": "BBC News"},
        "author": "BBC News",
        "title": "Kabul mourns 100 dead after ambulance bomb",
        "description": "Sunday is a day of mourning, as funerals take place and people search hospitals for survivors.",
        "url": "http://www.bbc.co.uk/news/world-asia-42850624",
        "urlToImage": "https://ichef-1.bbci.co.uk/news/1024/branded_news/F170/production/_99780816_hi044381668.jpg",
        "publishedAt": "2018-01-28T08:10:21Z"
    }, {
        "source": {"id": "bbc-news", "name": "BBC News"},
        "author": "BBC News",
        "title": "Payout for victims of cryptocurrency hack",
        "description": "Tokyo-based digital currency exchange Coincheck says it will reimburse some 260,000 victims of theft.",
        "url": "http://www.bbc.co.uk/news/world-asia-42850194",
        "urlToImage": "https://ichef-1.bbci.co.uk/news/1024/branded_news/1EC5/production/_99777870_execs.jpg",
        "publishedAt": "2018-01-28T07:33:04Z"
    }, {
        "source": {"id": "bbc-news", "name": "BBC News"},
        "author": "BBC News",
        "title": "French woman saved from 'Killer Mountain'",
        "description": "Elisabeth Revol is saved by a team of elite Polish climbers, who scaled 1,000m in a night to find her.",
        "url": "http://www.bbc.co.uk/news/world-asia-42849057",
        "urlToImage": "https://ichef-1.bbci.co.uk/news/1024/branded_news/7B6D/production/_99779513_hi044370647.jpg",
        "publishedAt": "2018-01-28T02:30:29Z"
    }, {
        "source": {"id": "bbc-news", "name": "BBC News"},
        "author": "BBC News",
        "title": "Calls to 'clean off' Banksy mural",
        "description": "Hundreds of people have been turning up to see the graffiti artist's work on a disused bridge in Hull.",
        "url": "http://www.bbc.co.uk/news/uk-42847060",
        "urlToImage": "https://ichef-1.bbci.co.uk/news/1024/branded_news/7339/production/_99779492_p05w9spp.jpg",
        "publishedAt": "2018-01-27T23:50:32Z"
    }, {
        "source": {"id": "bbc-news", "name": "BBC News"},
        "author": "BBC News",
        "title": "Israel criticises Polish Holocaust law",
        "description": "Israel's prime minister attacks a law that would make it illegal to describe Nazi death camps as Polish.",
        "url": "http://www.bbc.co.uk/news/world-middle-east-42848842",
        "urlToImage": "https://ichef-1.bbci.co.uk/news/1024/branded_news/6335/production/_99779352_gettyimages-461706580.jpg",
        "publishedAt": "2018-01-27T23:01:09Z"
    }, {
        "source": {"id": "bbc-news", "name": "BBC News"},
        "author": "BBC News",
        "title": "Wynn quits as Republican finance chair",
        "description": "The US casino mogul steps down amid sexual harassment allegations he has called \"preposterous\".",
        "url": "http://www.bbc.co.uk/news/world-us-canada-42848795",
        "urlToImage": "https://ichef-1.bbci.co.uk/news/1024/branded_news/13125/production/_99771187_gettyimages-823238544.jpg",
        "publishedAt": "2018-01-27T20:12:15Z"
    }]
}