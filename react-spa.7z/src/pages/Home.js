import React, { Component } from 'react';
// import ReactDOM from 'react-dom';

class Home extends Component {
    render() {
        return(
            <h1>BBC.com</h1>
        );
    }
}

export default Home;