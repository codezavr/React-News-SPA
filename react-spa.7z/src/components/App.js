import React, { Component } from 'react';
import createBrowserHistory from 'history/createBrowserHistory'
import Masonry from 'masonry-layout';

import {
    Router,
    Route,
    NavLink,
    Link
} from 'react-router-dom';

import Home from '../pages/Home';
import Sport from '../pages/Sport';

import News from '../components/News'
import SearchBar from "./SearchBar";

const NewsAPI = require('newsapi');
const newsapi = new NewsAPI('53b10146d873487593e621d722537d74');

// Create browser history
const history = createBrowserHistory();

class App extends Component {

    constructor(props) {
        super(props);

        this.q = 'bitcoin';

        this.state = {
            TESTSTATUS: false,
            articles: [],
            changedArticles: [],
            searchValue: '',
            sortByRating: false
        };
    }

    // --------------------- SETTERS ---------------------

    searchInputSet(value) {

        this.setState({
            searchValue: value,
        });

    }

    // --------------------- ACTIONS ---------------------

    searchInput() {

            let searchValue = this.state.searchValue;

            let sortedArticles = this.state.articles.filter((item, index, arr) => {

                // One of fields is missed
                if(item.author === null || item.title === null || item.description === null ) return;

                if(
                    !(item.author.toLowerCase().indexOf(searchValue) < 0) ||
                    !(item.title.toLowerCase().indexOf(searchValue) < 0) ||
                    !(item.description.toLowerCase().indexOf(searchValue) < 0)
                ) {
                    return item
                }

            });

            this.setState({
                changedArticles: sortedArticles,
            });

    }

    sortByRating() {

        let sortedArticles = this.state.changedArticles.sort((itemOne, itemTwo) => {
            if(this.state.sortByRating) {
                return +itemOne.rating - +itemTwo.rating;
            } else {
                return +itemTwo.rating - +itemOne.rating;
            }
        });

        this.setState({
            changedArticles: sortedArticles,
            sortByRating: !this.state.sortByRating
        });
    }

    // --------------------- LIFECICLE ---------------------

    componentWillMount() {

        newsapi.v2.everything({
            q: this.q,
            sources: 'bbc-news,the-verge',
            domains: 'bbc.co.uk, techcrunch.com',
            from: '2017-12-01',
            to: '2017-12-12',
            language: 'en',
            sortBy: 'relevancy',
            page: 1
        }).then(response => {

            if(response.articles.length === 0) return;

            response.articles.forEach((item) => {
                item.rating = Math.round(Math.random() * (999 - 1) + 1);
            });

            this.setState({
                articles: response.articles,
                changedArticles: response.articles
            });
        });

    }

    componentDidMount() {
        let page = 1;

        window.addEventListener('scroll', () => {

            if((window.innerHeight + window.scrollY) >= document.body.offsetHeight) {
                console.log(page, this.state);
                ++page;

                if(this.state.searchValue !== '') return;

                newsapi.v2.everything({
                    q: this.q,
                    sources: 'bbc-news,the-verge',
                    domains: 'bbc.co.uk, techcrunch.com',
                    from: '2017-12-01',
                    to: '2017-12-12',
                    language: 'en',
                    sortBy: 'relevancy',
                    page: page
                }).then(response => {
                    response.articles.forEach((item) => {
                        item.rating = Math.round(Math.random() * (999 - 1) + 1);
                    });

                    this.setState({
                        articles: this.state.articles.concat(response.articles),
                        changedArticles: this.state.changedArticles.concat(response.articles)
                    });
                });
            }
        });

    }

    componentWillUpdate(prevProps, prevState) {

    }

    componentDidUpdate(prevProps, prevState) {
        if(prevState.searchValue !== this.state.searchValue) this.searchInput();

        let msnry = new Masonry(document.querySelector('.grid'), {
            itemSelector: '.grid-item',
            columnWidth: '.grid-item',
            percentPosition: true,
            gutter: 10
        });

        setTimeout(() => {
            msnry.layout();
        }, 500);
    }

    render() {
        return (
            <Router history={history}>
                <div>
                    <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
                        <Link className="navbar-brand" to="/">BBC NEWS</Link>
                        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"> </span>
                        </button>

                        <div className="collapse navbar-collapse" id="navbarColor01">
                            <ul className="navbar-nav mr-auto">
                                <li className="nav-item">
                                    <Link className="nav-link" to="/">Home</Link>
                                </li>
                                <li className="nav-item">
                                    <Link className="nav-link" to="/sport">Sport</Link>
                                </li>
                            </ul>
                            <SearchBar valueOnSearch={this.searchInputSet.bind(this)} />
                        </div>
                    </nav>
                    <section className="news">
                        <div className="container">
                            <Route exact path="/" component={Home}/>
                            <Route path="/sport" component={Sport}/>

                            <button type="button"
                                    className={ this.state.changedArticles.length > 0 ? "btn btn-primary btn-sm" : "d-none"
                            }
                                    onClick={this.sortByRating.bind(this)}>Sort By Rating</button>
                        </div>
                        <div className="container">
                            {
                                this.state.changedArticles ?
                                    <div className="grid">
                                        { this.state.changedArticles.map((item, index, arr) => {
                                            return <News
                                            key={index}
                                            author={item.author}
                                            category={item.source.id}
                                            title={item.title}
                                            description={item.description}
                                            url={item.url}
                                            image={item.urlToImage}
                                            rating={item.rating || 0}
                                            />
                                        }) }
                                    </div> : 'NO NEWS for you'
                            }


                        </div>
                    </section>
                </div>
            </Router>
        )
    }
}

export default App;